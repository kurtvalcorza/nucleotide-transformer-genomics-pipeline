"""Review probes for tutorials/nucleotide_transformer_colab.ipynb (row 58, NTP-*).

Environment (labelled REDUCED SCALE, CPU only): conda env eo-notebook-test, Python 3.12.14, torch 2.13.0+cpu
(notebook pins 2.14.0), transformers 4.57.6, safetensors 0.8.0, numpy 2.5.3; CUDA_VISIBLE_DEVICES=-1;
torch threads capped at 4. The package is imported from the reviewed worktree's src/ (the notebook carries the
same three modules verbatim; probe P0 checks that byte for byte). The model snapshot is read from the local clone's
pre-staged weights/ directory (verified by verify_snapshot before load). This is NOT a Colab or clean-runtime run.

Usage: python run_probes.py <worktree> <weights_dir> <out_json>
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import sys
import tempfile
import time
from pathlib import Path

WT = Path(sys.argv[1])
WEIGHTS = Path(sys.argv[2])
OUT = Path(sys.argv[3])
sys.path.insert(0, str(WT / "src"))
results: dict = {"environment": {}, "probes": {}}


def save() -> None:
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


# ---------------------------------------------------------------- P0 carried cells == package modules
nb = json.loads((WT / "tutorials/nucleotide_transformer_colab.ipynb").read_text(encoding="utf-8"))
cells = nb["cells"]
p0 = {}
for idx, mod in ((5, "metrics.py"), (7, "pipeline.py"), (9, "samples.py")):
    cell = "".join(cells[idx]["source"])
    src = (WT / "src/nucleotide_transformer_genomics_pipeline" / mod).read_text(encoding="utf-8")
    src_lines = [ln for ln in src.splitlines() if not ln.startswith("from .")]
    cell_lines = cell.splitlines()
    p0[mod] = {"cell": idx, "cell_chars": len(cell), "lines_only_in_module": len(set(src_lines) - set(cell_lines)), "lines_only_in_cell": len(set(cell_lines) - set(src_lines))}
results["probes"]["P0_carried_modules_match"] = p0
results["probes"]["P0_cell_sizes_chars"] = {i: len("".join(c["source"])) for i, c in enumerate(cells)}
save()

from nucleotide_transformer_genomics_pipeline import samples, metrics  # noqa: E402

# ---------------------------------------------------------------- P1 BYOD minimum size through cell 13's logic
def cell13_byod(n: int, seed: int = 42) -> dict:
    rng = random.Random(n)
    rows = [{"id": f"s{i}", "sequence": "".join(rng.choice("ACGT") for _ in range(60)), "label": i % 2} for i in range(n)]
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "byod.csv"
        with open(path, "w", encoding="utf-8", newline="") as h:
            w = csv.DictWriter(h, fieldnames=["id", "sequence", "label"])
            w.writeheader()
            w.writerows(rows)
        try:
            records = samples.load_byod_dataset(path)
            splits = samples.split_dataset(records, seed=seed)
            sizes = {k: len(v) for k, v in splits.items()}
            # exactly what cell 13 does next
            manifests = {name: samples.validate_dataset(part, require_both_labels=(name == "train")) for name, part in splits.items()}
            return {"n": n, "sizes": sizes, "outcome": "accepted"}
        except ValueError as exc:
            return {"n": n, "sizes": locals().get("sizes"), "outcome": "ValueError", "message": str(exc)}


p1 = [cell13_byod(n) for n in (8, 10, 20, 40, 49, 50, 60)]
first_ok = next((n for n in range(8, 200) if cell13_byod(n)["outcome"] == "accepted"), None)
results["probes"]["P1_byod_min_records"] = {"promised_minimum": "at least eight sequences (cell 0 BYOD paragraph; MIN_RECORDS=8)", "runs": p1, "smallest_n_accepted_by_cell13": first_ok}
save()

# ---------------------------------------------------------------- model-backed probes (reduced scale)
import torch  # noqa: E402

torch.set_num_threads(4)
from nucleotide_transformer_genomics_pipeline import pipeline as P  # noqa: E402
import transformers  # noqa: E402

results["environment"] = {"python": sys.version.split()[0], "torch": torch.__version__, "transformers": transformers.__version__, "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"), "cuda_available": torch.cuda.is_available(), "threads": torch.get_num_threads(), "scale": "REDUCED: 48 train / 32 test windows, 1 epoch, no validation split in P3 (final epoch kept)"}
save()

t0 = time.perf_counter()
pipe = P.NucleotideTransformerPipeline.from_pretrained(device="cpu", weights_dir=WEIGHTS)
results["probes"]["P2_load"] = {"seconds": round(time.perf_counter() - t0, 1), "device": pipe.device, "has_source_attr": hasattr(pipe, "source")}

splits = samples.sample_dataset()
rng = random.Random(0)
train = rng.sample([r for r in splits["train"] if r["label"] == 1], 24) + rng.sample([r for r in splits["train"] if r["label"] == 0], 24)
val = rng.sample([r for r in splits["validation"] if r["label"] == 1], 8) + rng.sample([r for r in splits["validation"] if r["label"] == 0], 8)
test = rng.sample([r for r in splits["test"] if r["label"] == 1], 16) + rng.sample([r for r in splits["test"] if r["label"] == 0], 16)

name11 = f"esm.encoder.layer.{P.NUM_LAYERS - 1}.attention.self.query.weight"
state = pipe._model.state_dict()
if name11 not in state:
    name11 = next(k for k in state if k.startswith(f"esm.encoder.layer.{P.NUM_LAYERS - 1}.") and k.endswith("weight"))
base_block11 = state[name11].detach().clone()
probe_seqs = [r["sequence"] for r in test[:4]]
v_before = pipe.embed(probe_seqs)
probe_before = pipe.linear_probe(train, test)

# P3: default-path adapt (reduced), then what a learner's rerun of Section 6 / Section 7 would see
t0 = time.perf_counter()
adapt1 = pipe.adapt(train, None, epochs=1, layers=2, seed=0)  # no val split -> final epoch kept, as the default run keeps a trained epoch (build record: epoch 2)
v_after = pipe.embed(probe_seqs)
probe_after = pipe.linear_probe(train, test)
block11_after_adapt = (pipe._model.state_dict()[name11] - base_block11).abs().max().item()
# optional experiment from the closing section: TRAINED_LAYERS = 0, rerun Section 7
adapt0 = pipe.adapt(train, None, epochs=1, layers=0, seed=0)
block11_after_layers0 = (pipe._model.state_dict()[name11] - base_block11).abs().max().item()
results["probes"]["P3_state_carryover_after_adapt"] = {
    "tensor_checked": name11,
    "embed_max_abs_change_after_adapt": max(abs(a - b) for va, vb in zip(v_before, v_after) for a, b in zip(va, vb)),
    "frozen_probe_before_adapt": {k: probe_before[k] for k in ("accuracy", "mcc")},
    "frozen_probe_rerun_after_adapt": {k: probe_after[k] for k in ("accuracy", "mcc")},
    "block11_max_abs_diff_from_base_after_adapt_layers2": block11_after_adapt,
    "block11_max_abs_diff_from_base_after_rerun_layers0": block11_after_layers0,
    "adapt_layers2_best_epoch": adapt1["best_epoch"],
    "adapt_layers0_reports_layers": adapt0["layers"],
    "adapt_layers0_n_trainable": adapt0["n_trainable"],
    "seconds": round(time.perf_counter() - t0, 1),
    "reading": "non-zero block-11 diff after a layers=0 rerun means the 'head alone' experiment trains on top of the previously fine-tuned blocks, and the 'frozen' probe/embeddings on rerun come from the adapted encoder",
}
save()

# P4: GC-determined stand-in BYOD set through cells 13 + 17 (fresh pipeline so the probe really is frozen)
pipe2 = P.NucleotideTransformerPipeline.from_pretrained(device="cpu", weights_dir=WEIGHTS)
r4 = random.Random(4)
rows = []
for i in range(80):
    gc_target = r4.uniform(0.3, 0.7)
    seq = "".join(r4.choice("GC") if r4.random() < gc_target else r4.choice("AT") for _ in range(251))
    gc = metrics.gc_content(seq)
    rows.append({"id": f"b{i}", "sequence": seq, "label": int(gc >= 0.5)})
sp = samples.split_dataset(rows, seed=42)
for name, part in sp.items():
    samples.validate_dataset(part, require_both_labels=(name == "train"))
maj = metrics.majority_baseline(sp["train"], sp["test"])
gcb = metrics.gc_threshold_baseline(sp["train"], sp["test"])
fp = pipe2.linear_probe(sp["train"], sp["test"])
ordering = fp["mcc"] > gcb["mcc"] > maj["mcc"]
results["probes"]["P4_byod_assert_cell17"] = {
    "standin": "80 synthetic 251-base windows labelled by GC >= 0.5 (a composition-defined task), split_dataset(seed=42)",
    "sizes": {k: len(v) for k, v in sp.items()},
    "majority": {k: maj[k] for k in ("accuracy", "mcc")},
    "gc_threshold": {k: gcb[k] for k in ("accuracy", "mcc")},
    "frozen_probe": {k: fp[k] for k in ("accuracy", "mcc")},
    "cell17_assert_frozen_gt_gc_gt_majority": ordering,
    "consequence": "AssertionError in Section 6; Sections 7-9 never run" if not ordering else "assert passes",
}
save()

# P5: masked prediction readout (sample sanity)
m = pipe2.predict_masked("ATTCCG" * 3 + "<mask>" + "ATTCCG" * 3, top_k=5)
results["probes"]["P5_masked_prediction"] = m
save()
print(json.dumps(results, indent=1, default=str))
